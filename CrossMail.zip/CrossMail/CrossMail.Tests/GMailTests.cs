﻿using Microsoft.Extensions.Configuration;
using OpenQA.Selenium;
using OpenQA.Selenium.Chrome;
using OpenQA.Selenium.Interactions;
using OpenQA.Selenium.Support.UI;
using System;
using Xunit;

namespace CrossMail.Test
{
    public class GMailTests: IDisposable
    {
        IWebDriver _browserDriver;
        IConfiguration _config;
        public GMailTests()
        {
            _browserDriver = new ChromeDriver("./");
            _config = new ConfigurationBuilder()
                .AddJsonFile("config.json")
                .Build();
        }

        public void Dispose()
        {
            _browserDriver.Quit();
        }

        [Fact]
        public void Should_Send_Email()
        {

            //_browserDriver.Navigate().GoToUrl("https://amazon.com/");    //going to stack overflow
            //System.Threading.Thread.Sleep(2000);
            //_browserDriver.FindElement(By.XPath("//*[@aria-label ='Open Menu'")).Click();
            //System.Threading.Thread.Sleep(2000);
            //_browserDriver.FindElement(By.XPath("//*[text() = 'Fire Tablets']")).Click();
            // System.Threading.Thread.Sleep(2000);


            //_browserDriver.FindElement(By.Name("q")).SendKeys("Hitler");
            //System.Threading.Thread.Sleep(2000);
            //_browserDriver.FindElement(By.Name("btnK")).Click();
            //System.Threading.Thread.Sleep(2000);
            //_browserDriver.FindElement(By.XPath("//*[text() ='Adolf Hitler - Quotes, Birthday & Death - Biography']")).Click();

            //  IWebElement element = _browserDriver.FindElement(By.XPath("//*[@class='gb_D gb_xc']"));
            // SelectElement selectElement = new SelectElement(element);
            //_browserDriver.FindElement(By.XPath("//*[@class='gb_D gb_xc']")).Click();
            // System.Threading.Thread.Sleep(2000);
            //_browserDriver.FindElement(By.ClassName("j1ei8c")).Click();
            //System.Threading.Thread.Sleep(2000);




            _browserDriver.Manage().Window.Maximize();
            _browserDriver.Navigate().GoToUrl("https://stackoverflow.com/");    //going to stack overflow
          
            _browserDriver.Manage().Timeouts().ImplicitWait = TimeSpan.FromSeconds(1);

            _browserDriver.FindElement(By.XPath("//*[text() ='Log in']")).Click();  // pressing log in button

             _browserDriver.FindElement(By.XPath("//button[@data-provider ='google']")).Click();    // pressing log in with google    

            _browserDriver.FindElement(By.Id("identifierId")).SendKeys("tt5515154@gmail.com");   //entering email

            _browserDriver.FindElement(By.Id("identifierNext")).Click();    //pressing Next

            _browserDriver.FindElement(By.XPath("//input[@name='password']")).SendKeys("testtester4040");   //entering password
            System.Threading.Thread.Sleep(2000);

            _browserDriver.FindElement(By.Id("passwordNext")).Click();  //pressing next
            System.Threading.Thread.Sleep(2000);

            _browserDriver.Navigate().GoToUrl("https://www.google.com/");   //going to google after login
            System.Threading.Thread.Sleep(1000);
        

            //-----------------------------------------Now we have logged into Google------------------------------------------------------------------
           
            _browserDriver.FindElement(By.XPath("//*[text() ='Gmail']")).Click();  // pressing Gmail button 
            System.Threading.Thread.Sleep(1000);

            _browserDriver.FindElement(By.XPath("//div[@class ='T-I T-I-KE L3']")).Click();  // pressing Compose button 
            System.Threading.Thread.Sleep(1000);

            _browserDriver.FindElement(By.XPath("//textarea[@name ='to']")).SendKeys("tt5515154@gmail.com");  // Reaching the 'to' address 
            System.Threading.Thread.Sleep(1000);

            _browserDriver.FindElement(By.XPath("//input[@name ='subjectbox']")).SendKeys("An Automated Message");  // Subject
            System.Threading.Thread.Sleep(1000);

            _browserDriver.FindElement(By.XPath("//div[@class ='Am Al editable LW-avf tS-tW']")).SendKeys("Finally!!!\n I have done it!\n Regards,\n Hamza");  // Body
            System.Threading.Thread.Sleep(1000);


            _browserDriver.FindElement(By.XPath("//*[@aria-label='More options']")).Click();  //*[@id=":bp"]
           // _browserDriver.FindElement(By.PartialLinkText("More options")).Click();
            // _browserDriver.FindElement(By.XPath("//*[@id=':a5']")).Click();  // steps to label it as social - pressing 3 dots
            // _browserDriver.FindElement(By.XPath("//*[@id=':hn']/div[2]")).Click();  // steps to label it as social - pressing 3 dots
            System.Threading.Thread.Sleep(1000);

            // _browserDriver.FindElement(By.XPath("//*[text() ='Label']")).Click();
           /* try  // does not work
                {
                _browserDriver.FindElement(By.Name("Label")).Click();
                }
            catch(NoSuchElementException e)
            {
                Console.WriteLine("label option not found with By Name Label\n");
            }*/
            try  // this works
            {
                _browserDriver.FindElement(By.XPath("//*[text() ='Label']")).Click();
            }
            catch
            {
                Console.WriteLine("label option Not found with By Xpath text = Label\n");
            }
            // _browserDriver.FindElement(By.XPath("//*[@id=':a2']")).Click();
            //_browserDriver.FindElement(By.XPath("  //*[@id=':hq']/div")).Click();  // pressing 'label'
            //_browserDriver.FindElement(By.XPath("//*[@class = 'J - N - Jz']")).Click();  // pressing 'label'
            System.Threading.Thread.Sleep(1000);
            /*  //this open up the social tab
            try
            {
                _browserDriver.FindElement(By.XPath("//*[text() ='Social']")).Click();  // choosing the label
            }
            catch
            {
                Console.WriteLine("Socail label not found with By Xpath text = Label\n");
            }
            */

          //  _browserDriver.FindElement(By.ClassName("J-LC-Jo J-J5-Ji")).Click();
           // _browserDriver.FindElement(By.ClassName("J-LC")).Click();  // choosing the label
            //_browserDriver.FindElement(By.XPath("//div[@title ='Social']")).Click();  // choosing the label
            //_browserDriver.FindElement(By.XPath("//*[text() ='Social']")).Click();  // choosing the label
            
            try
            {
                _browserDriver.FindElement(By.ClassName("J-LC-Jo J-J5-Ji")).Click();
            }
            catch(NoSuchElementException e)
            {
                Console.WriteLine("Socail label not found with By class\n");
            }
            try
            {
                _browserDriver.FindElement(By.ClassName("J-LC")).Click();  // choosing the label
            }
            catch (NoSuchElementException e)
            {
                Console.WriteLine("Socail label not found with By Xpath text = Label\n");
            }

            try
            {
                _browserDriver.FindElement(By.XPath("//div[@title ='Social']")).Click();  // choosing the label
            }
            catch (ElementNotVisibleException e)
            {
                Console.WriteLine("Socail label not found with By Xpath text = Label\n");
            }

            System.Threading.Thread.Sleep(1000);
            try
            {
                _browserDriver.FindElement(By.TagName("Social")).Click();  // choosing the label
            }
            catch (NoSuchElementException e)
            {
                Console.WriteLine("Socail label not found with with tag name= Label\n");
            }
            System.Threading.Thread.Sleep(1000);
            try
            {
                _browserDriver.FindElement(By.XPath("//*[text() ='Social']")).Click();  // choosing the label
            }
            catch (ElementNotVisibleException e)
            {
                Console.WriteLine("Socail label not found with with texxt name= Label\n");
            }
            System.Threading.Thread.Sleep(1000);

            // #\:lt > div
            // //*[@id=":lt"]/div

            Actions actions = new Actions(_browserDriver);
            actions.SendKeys(Keys.Control)
                .SendKeys(Keys.Enter);


           // _browserDriver.FindElement(By.Id(":i6")).Click();  // Pressing 'Send' button
            System.Threading.Thread.Sleep(1000);
            
            
            



            /*
            _browserDriver.Navigate().GoToUrl("https://mail.google.com/");
            IWebElement userElement = _browserDriver.FindElement(By.Id("identifierId"));
            userElement.SendKeys("hamza40nazir@gmail.com");
            _browserDriver.Manage().Timeouts().ImplicitWait = TimeSpan.FromSeconds(2);
            _browserDriver.FindElement(By.ClassName("CwaK9")).Click();

            _browserDriver.Manage().Timeouts().ImplicitWait = TimeSpan.FromSeconds(5);

            var passwordElement = _browserDriver.FindElement(By.Name("password"));
            userElement.SendKeys("hamzaNAZIR1997");

            _browserDriver.FindElement(By.Id("passwordNext")).Click();

            _browserDriver.Manage().Timeouts().ImplicitWait = TimeSpan.FromSeconds(6);

            var composeElement = _browserDriver.FindElement(By.XPath("//*[@role='button' and (.)='COMPSE']"));
            composeElement.Click();

            _browserDriver.FindElement(By.Name("to")).Clear();
            _browserDriver.FindElement(By.Name("to")).SendKeys("hamza40nazir@gmail.com");

            _browserDriver.Manage().Timeouts().ImplicitWait = TimeSpan.FromSeconds(2);

            _browserDriver.FindElement(By.Name("subjectbox")).Clear();
            _browserDriver.FindElement(By.Name("to")).SendKeys("Automated Mail");
            _browserDriver.Manage().Timeouts().ImplicitWait = TimeSpan.FromSeconds(2);

            var body = _browserDriver.FindElement(By.XPath("//*[@role='textbox']"));
            body.SendKeys("This is the Automated Body");



            var sendButtonElement = _browserDriver.FindElement(By.XPath("//*[@role='button' and text()='Send']"));
            sendButtonElement.Click();
            */

        }
    }
}
